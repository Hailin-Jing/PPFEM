/*---------------------------------------------------------------------------+
|   EasyMesh - A Two-Dimensional Quality Mesh Generator                      |
|                                                                            |
|   Copyright (C) 2008 Bojan Niceno - bojan.niceno@psi.ch                    |
+---------------------------------------------------------------------------*/
// #define real     float
// #define mpi_real MPI_FLOAT

#define real     double
#define mpi_real MPI_DOUBLE
